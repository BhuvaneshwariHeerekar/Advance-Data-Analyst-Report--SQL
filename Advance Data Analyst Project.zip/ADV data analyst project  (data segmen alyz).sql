--DATA SEGMENTATION --
 /* Segment products into cast ranges and 
 count how many products fall into each segment */
 WITH product_segments AS (
 SELECT
 product_key,
 product_name,
 cost,
 CASE 
	WHEN cost < 100 THEN 'Below 100'
	WHEN cost BETWEEN 100 AND 500  THEN '100 -500'
	WHEN cost BETWEEN 500 AND 1000 THEN '500 -1000'
	ELSE 'Above 1000'
	END cost_range
FROM dbo.[gold.dim_products]
)

SELECT 
cost_range ,
COUNT(product_key) AS total_products
FROM product_segments
GROUP BY cost_range
ORDER BY total_products DESC

/* NOTE : not have enough dimension to create insights then take one measure and convert it into a dimension using 'case when'
and then aggregate your other measures based on this new dimension */
---------------------------------------------------------------------------------------------------------------------------------
/*Group customers into three segments based on their spending behavior:
	-VIP :Customers with at least 12 months of history and spending more than 5,000.
	-Regular :Customers with ar least 12 months of history but spending 5,000 or less.
	-New : Customers with a lifespan less than 12 months .
AND find the total number of customers by each group */

-- 2 step :convert query into CTE --
WITH customer_spending AS (
-- 1 step :writing a query 
SELECT 
c.customer_key,
SUM(f.sales_amount) AS total_spending,
MIN(f.order_date) AS first_order,
MAX(f.order_date) AS last_order,
DATEDIFF(MONTH,MIN(f.order_date),MAX(f.order_date)) AS lifespan
FROM dbo.[gold.fact_sales] f
LEFT JOIN dbo.[gold.dim_customers] c
ON f.customer_key = c.customer_key 
GROUP BY c.customer_key 
)

--4 step :subquery --
SELECT 
customer_segment,
COUNT(customer_key) AS total_customers
FROM (
-- 3 step :TEST CTE and other funtion --
	SELECT
	customer_key,
	total_spending,
	lifespan,
	CASE 
		WHEN lifespan >= 12 AND total_spending > 5000 THEN 'VIP'
		WHEN lifespan >= 12 AND total_spending <=5000 THEN 'Regular'
		ELSE 'New'
		END customer_segment

	FROM customer_spending
	) t
	--4 step include--
GROUP BY customer_segment  
ORDER BY total_customers DESC