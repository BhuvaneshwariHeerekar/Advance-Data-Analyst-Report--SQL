-- REPORTIN 1 : BUILD CUSTOMER report  --
/* --------------------------------------------------------
Customer Report 
--------------------------------------------------------
Purpose :
-- This report consolidates key customer metrics and behaviors 

Highlights :
1. Gathers essential fields such as names, ages,and transaction details.
2. Segments customers into categories (VIP ,Regular, New ) and age groups.
3. Aggregates customer- level metrics :
   -total order 
   -total sales
   -total quantity purchased 
   -total products
   -lifespan (in months)
4. Caleculates valuable KPIs:
   -recency (months since last order )
   -average order value 
   -average monthly spend       
   _______________________________________________________ */
 CREATE VIEW  dbo.[gold.report_customers] AS
 WITH base_query AS  (
   SELECT 
   f.order_number,
   f.product_key ,
   f.order_date,
   f.sales_amount,
   f.quantity,
   c.customer_key,
   c.customer_number,                                                       
   CONCAT(c.first_name,' ',c.last_name) AS customer_name ,                  
                                                                         
   DATEDIFF(YEAR,c.birthdate,GETDATE())  age                             
   FROM dbo.[gold.fact_sales] f                                           
   LEFT JOIN dbo.[gold.dim_customers] c                                    
   ON f.customer_key = c.customer_key 
   WHERE order_date IS NOT NULL 
   )
   ,customer_aggregation AS ( 

   SELECT 
   customer_key,
   customer_number,
   customer_name,
   age,
   COUNT(DISTINCT order_number) AS total_orders,
   SUM(sales_amount) AS total_sales,
   SUM(quantity) AS total_quantity,
   COUNT(DISTINCT product_key) AS total_products, 
   MAX(order_date) AS last_order_date,
   DATEDIFF(MONTH,MIN(order_date),MAX(order_date)) AS lifespan 
   FROM base_query 
   GROUP BY 
       customer_key,
       customer_number,
       customer_name,
       age
  )
  SELECT 
   customer_key,
   customer_number,
   customer_name,
    age,
         CASE 
           WHEN age < 20 THEN 'Under 20'
           WHEN age BETWEEN  20 AND 29  THEN '20-29'
           WHEN age BETWEEN  30 AND 39 THEN '30-39'
           WHEN age BETWEEN 40 AND 49 THEN  '40-49'
           ELSE '50 AND above'
           END AS age_group,
       
       CASE 
              WHEN lifespan >= 12 AND total_sales > 5000 THEN 'VIP'
              WHEN lifespan >= 12 AND total_sales <= 5000 THEN 'Regular'
              ELSE 'New'
              END AS customer_segment,
  last_order_date,
  DATEDIFF(MONTH,last_order_date,GETDATE()) AS recency,
  total_orders,
  total_sales,
  total_quantity,
  total_products, 
  lifespan ,
  --should not include 0 in avg so case statement and divide to find kpi b)
  CASE 
       WHEN total_orders = 0 THEN 0
       ELSE total_sales / total_orders 
       END AS avg_order_value ,
 --should not include 0 in avg so case statement and divide to find kpi  c)
CASE 
     WHEN lifespan =0 THEN total_sales
     ELSE  total_sales / lifespan 
     END AS avg_monthly_spend
FROM customer_aggregation 





--check view--
SELECT * FROM dbo.[gold.report_customers]





/*Require  Steps for report */
--1  select column 
--2  filter the data
--3  transformation to do any aggregate
--4  CTE create (as intermediate result ) 1
--5  CTE result query test 
--6  AGGREGATIONS  and remove dublicate and make new insights 
--7 group by data 
--8 segment customers  
--(CTE create for final result ) 2 , test 2 CTE query   ,  case when statement  a) vip , age_group 
--9 create KPI s  
/*    a) recency(datediff) ,
      b) average order value = total sales / total nr. of orders  
      c) average monthly spending = total sales / Nr.of months     */
--10 create a view keping the entire query in it so that other end user use it to view data in tableau or power bi
--11 check view query 