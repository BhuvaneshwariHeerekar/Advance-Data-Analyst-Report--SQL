--PART- TO - WHOLE  ANALYSIS --
--Which categories contribute the most to overall sales?
WITH category_sales AS (
--1st subquery and 2nd CTE --   
SELECT                
category,
SUM(sales_amount) total_sales
FROM dbo.[gold.fact_sales] f
LEFT JOIN dbo.[gold.dim_products] p
ON p.product_key = f.product_key
GROUP BY category 
)
--1st TEST CTE then 2nd add function  
SELECT 
category,
total_sales,
SUM(total_sales) OVER() overall_sales,
--we are dividing , multi 100, cast as float (for values) ,round by 2 (for decimal) , concat with % (to convert in percentage) , order by 
CONCAT( ROUND( ( CAST(total_sales AS FLOAT) / SUM(total_sales) OVER() )* 100 , 2) ,'%' )AS percentage_of_total
FROM [category_sales]
ORDER BY total_sales DESC
