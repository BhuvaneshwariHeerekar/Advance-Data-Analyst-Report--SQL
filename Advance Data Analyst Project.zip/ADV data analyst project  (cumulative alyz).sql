--CUMULATIVE ANALYSIS --
--calculate the total sales per month and
--the running total of sales over time --
SELECT  
order_date,
total_sales,            --you can add PARTITION BY order_date to divide in parts--
SUM(total_sales) OVER (    ORDER BY order_date) AS running_total_sales,    --window function --
AVG(avg_price) OVER (ORDER BY order_date ) AS moving_average_price
FROM (

SELECT 
DATETRUNC(year,order_date) AS order_date,
SUM(sales_amount) AS total_sales,
AVG(price) AS avg_price
FROM dbo.[gold.fact_sales]
WHERE order_date IS NOT NULL
GROUP BY DATETRUNC(year,order_date)
)t

--note :The ORDER BY clause is invalid in views, inline functions, derived tables, subqueries, and common table expressions--
--(as it is already sorted in window function) --

